package controller;

import model.Producto;

public class ProductoController {
    private Producto producto;

    public ProductoController(Producto producto) {
        this.producto = producto;
    }

    public void actualizarProducto(String nombre, double precio, int cantidad, String categoria) {
        this.producto = new Producto(nombre, precio, cantidad, categoria);
    }

    public Producto getProducto() {
        return producto;
    }
}