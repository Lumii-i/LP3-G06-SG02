package ui;

import controller.ProductoController;
import model.Producto;

import javax.swing.*;
import java.awt.*;

public class InventarioUI extends JFrame {
    public InventarioUI() {
        setTitle("Inventario");
        setSize(400,300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTextField nombre = new JTextField();
        JTextField precio = new JTextField();
        JTextField cantidad = new JTextField();
        JTextField categoria = new JTextField();
        JLabel resultado = new JLabel("Datos del producto aparecerán aquí");

        JButton actualizar = new JButton("Actualizar Producto");

        ProductoController controller = new ProductoController(new Producto("",0,0,""));

        actualizar.addActionListener(e -> {
            controller.actualizarProducto(
                nombre.getText(),
                Double.parseDouble(precio.getText()),
                Integer.parseInt(cantidad.getText()),
                categoria.getText()
            );
            resultado.setText(controller.getProducto().toString());
        });

        setLayout(new GridLayout(6,2));
        add(new JLabel("Nombre:")); add(nombre);
        add(new JLabel("Precio:")); add(precio);
        add(new JLabel("Cantidad:")); add(cantidad);
        add(new JLabel("Categoria:")); add(categoria);
        add(actualizar); add(resultado);
    }
}